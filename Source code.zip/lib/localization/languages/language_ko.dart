
final Map<String, String> koKR = {};
