import 'package:get/get.dart';
class OnBoardingController extends GetxController {

}
